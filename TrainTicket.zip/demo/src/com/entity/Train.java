package com.entity;
//������ʾ�г���Ϣ
public class Train {
	private int id;
	private String price;
	private String destination;
	private String trainID;
	private int remain;
	public Train()
	{
		this.id=1;
		this.price="1";
		this.destination="1";
		this.trainID="1";
		this.remain=1;
	}
	public Train(int id)
	{
		this.id=id;
	}
	public Train(int id,String price,String destination,String trainID,int remain) {
		this.id=id;
		this.price=price;
		this.destination=destination;
		this.trainID=trainID;
		this.remain=remain;
	}

	public int getID() {
		return id;
	}

	public void setID(int id) {
		this.id = id;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price=price;
	}

	public String destination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String gettrainID() {
		return trainID;
	}

	public void settrainID(String trainID) {
		this.trainID=trainID;
	}
	public int getRemain() {
		return remain;
	}
}